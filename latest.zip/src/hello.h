/Git Bash.lnk /Git Bash.vbs /ReleaseNotes.rtf /bin /cmd /doc /etc /git-cheetah /lib /libexec /share /ssl /unins000.dat /unins000.exe hello.h */
